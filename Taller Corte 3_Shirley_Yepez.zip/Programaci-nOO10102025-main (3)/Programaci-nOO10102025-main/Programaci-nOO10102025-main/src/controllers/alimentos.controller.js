import Alimentos from "../services/alimentos.service.js";
import productos from "../datos/alimentos.datos.js";

const servicio = new Alimentos();


export const getFiltrados = (req, res) => {
    console.log("Punto 1 ejecutado");
    res.json(servicio.productosActivos(productos));
};


export const gettotalActivos = (req, res) => {
    console.log("Punto 2 ejecutado");
    res.json(servicio.precioTotalActivos(productos));
};


export const getMayores = (req, res) => {
    console.log("Punto 3 ejecutado");
    res.json(servicio.ENTREGAS(productos));  
};

export const getDolares = (req, res) => {
    console.log("Punto 4 ejecutado");
    res.json(servicio.convertirAPreciosDolares(productos));
};
