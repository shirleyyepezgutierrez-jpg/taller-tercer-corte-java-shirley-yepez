/* EN ESTE ARCHIVO VAN LAS FUNCIONES QUE RECIBEN LOS 
DATOS DE LAS PETICIONES HTTP Y ENVÍA LAS RTAS JSON CON 
ESTADOS HTTP */

/* CREAR UNA FUNCIÓN PARA MOSTRAR UNA RTA EN CONSOLA */
export const consulta = (req, res, next) => {
  console.log("...revisa la terminal...");
};
