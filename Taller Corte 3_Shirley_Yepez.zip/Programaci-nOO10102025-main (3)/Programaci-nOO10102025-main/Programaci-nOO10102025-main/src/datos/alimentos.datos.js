/* este archivo contiene el array de objetos... */
const productos = [
  {
    id: 1,
    nombre: "Producto A",
    precio: 50,
    categoria: {
      nombre: "Categoría 1",
      descripcion: "Descripción de la categoría 1",
      formatos: [
        { formato: "Caja", cantidad: 10 },
        { formato: "Botella", cantidad: 5 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 1",
      entregas: [
        { fecha: "2022-10-01", cantidad: 100 },
        { fecha: "2022-09-25", cantidad: 200 },
        { fecha: "2022-09-20", cantidad: 150 },
        { fecha: "2022-09-15", cantidad: 180 },
        { fecha: "2022-09-10", cantidad: 120 },
      ],
      estado: "activo",
    },
    inventario: {
      disponible: 300,
      reservado: 50,
      total: 350,
    },
  },
  {
    id: 2,
    nombre: "Producto B",
    precio: 120,
    categoria: {
      nombre: "Categoría 2",
      descripcion: "Descripción de la categoría 2",
      formatos: [
        { formato: "Paquete", cantidad: 20 },
        { formato: "Unidad", cantidad: 1 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 2",
      entregas: [
        { fecha: "2025-10-02", cantidad: 80 },
        { fecha: "2025-09-28", cantidad: 60 },
        { fecha: "2025-09-22", cantidad: 90 },
        { fecha: "2025-09-18", cantidad: 110 },
        { fecha: "2025-09-12", cantidad: 130 },
      ],
    },
    inventario: {
      disponible: 450,
      reservado: 150,
      total: 600,
    },
    estado: "inactivo",
  },
  {
    id: 3,
    nombre: "Producto C",
    precio: 200,
    categoria: {
      nombre: "Categoría 3",
      descripcion: "Descripción de la categoría 3",
      formatos: [
        { formato: "Lata", cantidad: 15 },
        { formato: "Tetra Pak", cantidad: 8 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 3",
      entregas: [
        { fecha: "2003-10-03", cantidad: 50 },
        { fecha: "2003-09-29", cantidad: 75 },
        { fecha: "2003-09-24", cantidad: 60 },
        { fecha: "2003-09-19", cantidad: 90 },
        { fecha: "2003-09-14", cantidad: 110 },
      ],
    },
    inventario: {
      disponible: 350,
      reservado: 70,
      total: 420,
    },
    estado: "activo",
  },
  {
    id: 4,
    nombre: "Producto D",
    precio: 80,
    categoria: {
      nombre: "Categoría 4",
      descripcion: "Descripción de la categoría 4",
      formatos: [
        { formato: "Paquete", cantidad: 10 },
        { formato: "Botella", cantidad: 6 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 4",
      entregas: [
        { fecha: "2023-10-04", cantidad: 100 },
        { fecha: "2023-09-30", cantidad: 80 },
        { fecha: "2023-09-26", cantidad: 120 },
        { fecha: "2023-09-20", cantidad: 90 },
        { fecha: "2023-09-15", cantidad: 140 },
      ],
    },
    inventario: {
      disponible: 500,
      reservado: 100,
      total: 600,
    },
    estado: "inactivo",
  },
  {
    id: 5,
    nombre: "Producto E",
    precio: 150,
    categoria: {
      nombre: "Categoría 5",
      descripcion: "Descripción de la categoría 5",
      formatos: [
        { formato: "Caja", cantidad: 5 },
        { formato: "Unidad", cantidad: 1 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 5",
      entregas: [
        { fecha: "2018-10-05", cantidad: 70 },
        { fecha: "2018-09-29", cantidad: 90 },
        { fecha: "2018-09-23", cantidad: 80 },
        { fecha: "2018-09-19", cantidad: 120 },
        { fecha: "2018-09-14", cantidad: 60 },
      ],
    },
    inventario: {
      disponible: 250,
      reservado: 30,
      total: 280,
    },
    estado: "activo",
  },
  {
     id: 6,
    nombre: "Producto F",
    precio: 200,
    categoria: {
      nombre: "Categoría 6",
      descripcion: "Descripción de la categoría 6",
      formatos: [
        { formato: "Caja", cantidad: 20 },
        { formato: "Botella", cantidad: 10 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 6",
      entregas: [
        { fecha: "2024-10-01", cantidad: 100 },
        { fecha: "2024-09-25", cantidad: 200 },
        { fecha: "2023-09-20", cantidad: 150 },
        { fecha: "2023-09-15", cantidad: 180 },
        { fecha: "2022-09-10", cantidad: 120 },
      ],
      estado: "activo",
    },
    inventario: {
      disponible: 300,
      reservado: 50,
      total: 350,
    },
    
  },
  {
    id: 7,
    nombre: "Producto G",
    precio: 220,
    categoria: {
      nombre: "Categoría 7",
      descripcion: "Descripción de la categoría 7",
      formatos: [
        { formato: "Paquete", cantidad: 30 },
        { formato: "Unidad", cantidad: 5 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 7",
      entregas: [
        { fecha: "2019-10-02", cantidad: 30 },
        { fecha: "2019-09-28", cantidad: 40 },
        { fecha: "2019-09-22", cantidad: 50 },
        { fecha: "2019-09-18", cantidad: 110 },
        { fecha: "2019-09-12", cantidad: 130 },
      ],
    },
    inventario: {
      disponible: 45,
      reservado: 15,
      total: 60,
    },
    estado: "inactivo",
  },
  {
    id: 8,
    nombre: "Producto H",
    precio: 300,
    categoria: {
      nombre: "Categoría 8",
      descripcion: "Descripción de la categoría 8",
      formatos: [
        { formato: "Lata", cantidad: 150 },
        { formato: "Tetra Pak", cantidad: 80 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 8",
      entregas: [
        { fecha: "2023-10-03", cantidad: 52 },
        { fecha: "2023-09-29", cantidad: 70 },
        { fecha: "2024-09-24", cantidad: 65 },
        { fecha: "2024-09-19", cantidad: 92 },
        { fecha: "2024-09-14", cantidad: 120 },
      ],
    },
    inventario: {
      disponible: 250,
      reservado: 60,
      total: 320,
    },
    estado: "activo",
  },
  {
    id: 9,
    nombre: "Producto I",
    precio: 80,
    categoria: {
      nombre: "Categoría 9",
      descripcion: "Descripción de la categoría 9",
      formatos: [
        { formato: "Paquete", cantidad: 100 },
        { formato: "Botella", cantidad: 60 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 9",
      entregas: [
        { fecha: "2023-10-04", cantidad: 150 },
        { fecha: "2023-09-30", cantidad: 80 },
        { fecha: "2023-09-26", cantidad: 130 },
        { fecha: "2023-09-20", cantidad: 90 },
        { fecha: "2023-09-15", cantidad: 120 },
      ],
    },
    inventario: {
      disponible: 400,
      reservado: 200,
      total: 700,
    },
    estado: "inactivo",
  },
  {
    id: 10,
    nombre: "Producto J",
    precio: 650,
    categoria: {
      nombre: "Categoría 10",
      descripcion: "Descripción de la categoría 10",
      formatos: [
        { formato: "Caja", cantidad: 6 },
        { formato: "Unidad", cantidad: 5 },
      ],
    },
    proveedor: {
      nombre: "Proveedor 10",
      entregas: [
        { fecha: "2019-10-05", cantidad: 80 },
        { fecha: "2019-09-29", cantidad: 70 },
        { fecha: "2019-09-23", cantidad: 60 },
        { fecha: "2019-09-19", cantidad: 220 },
        { fecha: "2019-09-14", cantidad: 90 },
      ],
    },
    inventario: {
      disponible: 250,
      reservado: 50,
      total: 380,
    },
    estado: "activo",
  }
];
export default productos;