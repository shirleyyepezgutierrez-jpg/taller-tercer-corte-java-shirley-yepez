import { Router } from "express";
import {
    getFiltrados,
    gettotalActivos,
    getMayores,
    getDolares
} from "../controllers/alimentos.controller.js";

const router = Router();

router.get("/alimentos/Filtrados", getFiltrados);
router.get("/alimentos/activos", gettotalActivos);
router.get("/alimentos/mayores", getMayores);
router.get("/alimentos/dolares", getDolares);

export default router;