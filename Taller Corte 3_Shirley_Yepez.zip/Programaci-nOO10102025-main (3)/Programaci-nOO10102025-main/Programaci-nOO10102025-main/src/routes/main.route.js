import express from 'express';
//import { consulta } from '../controllers/main.controller.js';
//import { consultarAutos, consultarBiblioteca, getFiltrados } from '../controllers/autos.controller.js';
 import { gettotalActivos } from '../controllers/alimentos.controller.js';
 import { getMayores } from '../controllers/alimentos.controller.js';
 import { getDolares } from '../controllers/alimentos.controller.js';
 import { getFiltrados } from '../controllers/alimentos.controller.js';

const router = express.Router();

/* ESTE ARCHIVO RESUELVE LAS RUTAS DESDE LAS PETICIONES 
QUE VIENEN DESDE EL NAVEGADOR O FRONTEND */
/* Aquí defino a qué función del controlador envío cada petición */
//router.get("/consulta", consulta);
//router.get("/consultarAutos", getFiltrados);
//router.get("/consultarBibiolteca", consultarBiblioteca);

router.get("/alimentos/Filtrados", getFiltrados);
router.get("/alimentos/activos", gettotalActivos);
router.get("/alimentos/mayores", getMayores);
export default router; 