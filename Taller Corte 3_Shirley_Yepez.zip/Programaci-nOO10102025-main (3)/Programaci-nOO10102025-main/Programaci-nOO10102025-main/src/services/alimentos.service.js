export default class Alimentos {
    constructor(){
        return this.mssge = "Ingrese al constructor de autos"
    }



    //METODOS DEFINIDOS DE LA CLASE
  productosActivos(a) {
  return a.filter((alimento) => alimento.estado === "activo");
    
}
 precioTotalActivos(productos){
        const activos = productos.filter(p => p.estado === "activo");
        return activos.reduce((total, p) => total + p.precio, 0);
    }

  
    ENTREGAS(productos){
        return productos.map(p => {
            const entregasFiltradas = p.proveedor?.entregas?.filter(e => {
                return new Date(e.fecha).getFullYear() >= 2020;
            }) || [];

            return {
                nombre: p.nombre,
                entregas: entregasFiltradas
            };
        });
    }
    

    sumarInventarioTotal(productos){
        return productos.reduce((sum, p) => {
            return sum + (p.inventario?.total || 0);
        }, 0);
    }
}